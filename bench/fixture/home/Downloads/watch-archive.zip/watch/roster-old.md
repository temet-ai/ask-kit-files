# Old roster

Captain Quirke had the Day Watch.
